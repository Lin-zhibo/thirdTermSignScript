import os
import hashlib
# from git.repo import Repo
# from git import Git

#create file and set password
stu_id="  "
classroom="401"
password=input("please input today's password for sign: ")
date=input("input date:")
text=stu_id+password+classroom
file_name=date+".txt"
txt=open(file_name,"a")
md5pwd=hashlib.md5(text.encode())
pwd=md5pwd.hexdigest()
txt.write(pwd)
txt.close()

#git operation
local_branch="main"  # or master
remote_branch="  "
message="sign_for"+date
os.system("git add "+file_name)
os.system("git commit -m "+message)
os.system("git push origin "+local_branch+":"+remote_branch)


# branch=" "

# path=os.path.abspath('.')
# repo=Repo(path)

# remote=repo.remote("origin")

# git=Git(repo.working_dir)
# git.add(file_name)
# git.commit('-m',message)

