import os
import hashlib
import datetime
# from git.repo import Repo
# from git import Git

#create file and set password
stu_id="  "  #change your id
classroom="401"
password=input("please input today's password for sign: ")
date=str(datetime.date.today())
text=stu_id+password+classroom
file_name=date
txt=open(file_name,"a")
md5pwd=hashlib.md5(text.encode())
pwd=md5pwd.hexdigest()
txt.write(pwd)
txt.close()

#git operation
local_branch="main"  # or master
remote_branch=" "  #your branch
message="sign_for"+date
os.system("git pull origin "+remote_branch)
os.system("git add "+file_name)
os.system("git commit -m "+message)
# try:
    # os.system("git push origin "+local_branch+":"+remote_branch)
# except:
#     os.system("git push -f origin "+local_branch+":"+remote_branch)
os.system("git push origin "+local_branch+":"+remote_branch)



# branch=" "

# path=os.path.abspath('.')
# repo=Repo(path)

# remote=repo.remote("origin")

# git=Git(repo.working_dir)
# git.add(file_name)
# git.commit('-m',message)

